# Kavya — The Operating Surface

Kavya is a philosophy-first Agent Plugin and MCP facilitator for intelligent business operations.

The central design rule is:

> **Philosophy first. Code as facilitator.**

Kavya does not hard-code one universal business operating model. The business provides objectives, scope, constraints, permissions, autonomy and implementation context. The plugin gives an agent structured primitives for observing work, reconstructing context, identifying leverage, designing interventions, measuring outcomes, learning from exceptions, and surfacing work.

## 0.2.0 — philosophy made executable

The 0.2.0 build upgrades the initial prototype from a small collection of CRUD-like tools into a facilitator architecture:

- evidence and provenance are first-class;
- expected/declared work and observed work remain separate;
- intent is explicitly modeled as inference, not fact;
- leverage scans remain diagnostic and objective-dependent;
- intervention planning is separated from execution;
- measurement contracts precede impact claims;
- outcome attribution is explicit;
- exception learning has validation gates;
- maturity is a vector across capability layers instead of a single ladder;
- `kavya_assess` provides a read-only composite diagnostic;
- the facilitator is deterministic and does not call an LLM;
- the current server performs no arbitrary external business actions.

## Three-layer design

**Human layer** — the editorial/product layer explaining Kavya.

**Agent layer** — `Agent.md` + `skills/kavya/SKILL.md`, encoding the philosophy, reasoning discipline and orchestration.

**Facilitator layer** — `server/core.mjs` + `server/index.mjs`, turning the invariants into structured state and MCP operations.

A later harness can replace the demonstration store with real connectors, memory, UI, permissions, event subscriptions and execution adapters without changing the philosophy.

## MCP surface

### Philosophy / diagnostics

`kavya_get_methodology` — canonical Kavya primitives.

`kavya_assess` — read-only composite diagnostic.

`kavya_get_maturity` — multidimensional maturity snapshot.

### Observe / understand

`kavya_configure_business` — explicit business configuration.

`kavya_ingest_observation` — expected/declared + observed work evidence.

`kavya_map_work` — work reconstruction and declared/observed divergence.

`kavya_infer_intent` — evidence-backed intent hypothesis.

### Intervene / measure

`kavya_identify_leverage` — objective-aware diagnostic scan.

`kavya_plan_intervention` — governed plan, not execution.

`kavya_define_measurement` — baseline/target contract.

`kavya_record_outcome` — outcome + numeric delta where possible.

### Learn / surface

`kavya_record_exception` — exception + resolution.

`kavya_promote_learning` — candidate knowledge/skill/policy/workflow/tool/UI learning.

`kavya_get_operating_surface` — current work context.

## Local development

Requires Node.js 20+.

```bash
npm install
npm test
npm run validate
npm start
```

Endpoints:

- `http://localhost:8787/mcp`
- `http://localhost:8787/healthz`

For current OpenAI plugin development, a portable plugin can package a root `plugin.json`, `skills/`, and an optional root `mcp.json`; MCP tools define live, controlled capabilities while skills define repeatable workflows. Streamable HTTP is the modern MCP transport for remote plugin servers. citeturn678604view1turn678604view2turn678604view4

Use MCP Inspector to test initialization, tool discovery, schemas, results, errors, annotations and authorization. For public submission, deploy a stable HTTPS `/mcp` endpoint and preserve authentication/authorization boundaries. citeturn678604view2
