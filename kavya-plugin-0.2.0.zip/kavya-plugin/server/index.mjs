import { createServer } from 'node:http';
import { randomUUID } from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StreamableHTTPServerTransport } from '@modelcontextprotocol/sdk/server/streamableHttp.js';
import { z } from 'zod';
import { KavyaStore, METHODOLOGY, mapWork, inferIntent, identifyLeverage, planIntervention, getOperatingSurface, maturitySnapshot, assess } from './core.mjs';

const root = path.dirname(fileURLToPath(import.meta.url));
const port = Number(process.env.KAVYA_PORT ?? 8787);
const statePath = process.env.KAVYA_STATE_PATH ?? path.resolve(root, '../.data/kavya-state.json');
const store = new KavyaStore(statePath);
const sessions = new Map();
const outputSchema = z.object({ result: z.any() });

const ok = (value) => ({ structuredContent: { result: value }, content: [{ type: 'text', text: JSON.stringify(value, null, 2) }] });

function register(server, name, spec, handler) {
  server.registerTool(name, { ...spec, outputSchema }, async (input) => {
    try { return ok(await handler(input)); }
    catch (err) { return ok({ ok: false, error: err instanceof Error ? err.message : String(err) }); }
  });
}

function serverFactory() {
  const server = new McpServer(
    { name: 'kavya', version: '0.2.0' },
    {
      instructions: `Kavya is a philosophy-first infrastructure facilitator. Role: infrastructure provider, not opinion maker. Loop: ${METHODOLOGY.loop.join(' → ')}. Keep evidence separate from inference. Do not invent business objectives, policy, or autonomy. Plan before external execution.`
    }
  );

  register(server, 'kavya_get_methodology', { title: 'Get Kavya methodology', description: 'Return Kavya philosophy, loop, capability layers and evidence chain. Read-only.', inputSchema: z.object({}), annotations: { readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: false } }, async () => METHODOLOGY);

  register(server, 'kavya_configure_business', {
    title: 'Configure business context', description: 'Persist explicit business objectives, constraints, privacy, permissions, autonomy, latency and maturity configuration.',
    inputSchema: z.object({ name: z.string().optional(), objective: z.object({ metric: z.string(), direction: z.enum(['increase', 'decrease', 'maintain']), baseline: z.any().optional(), target: z.any().optional(), scope: z.string().optional(), constraints: z.array(z.string()).optional() }).optional(), objectives: z.array(z.record(z.string(), z.any())).optional(), constraints: z.array(z.string()).optional(), scope: z.record(z.string(), z.any()).optional(), measurement: z.record(z.string(), z.any()).optional(), permissions: z.record(z.string(), z.any()).optional(), privacy: z.record(z.string(), z.any()).optional(), autonomy: z.record(z.string(), z.any()).optional(), latency: z.record(z.string(), z.any()).optional(), maturity: z.record(z.string(), z.any()).optional() }),
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: true, openWorldHint: false }
  }, async (input) => store.configureBusiness(input));

  register(server, 'kavya_ingest_observation', {
    title: 'Record work observation', description: 'Record declared/expected work and observed work evidence. The employee is not the optimization target.',
    inputSchema: z.object({ id: z.string().optional(), observedAt: z.string().optional(), workObject: z.object({ id: z.string(), type: z.string().optional(), name: z.string().optional(), state: z.string().optional() }), declaredWork: z.string().optional(), observedWork: z.array(z.string()).optional(), signals: z.array(z.record(z.string(), z.any())).optional(), context: z.record(z.string(), z.any()).optional(), outcome: z.any().optional(), evidence: z.array(z.any()).optional(), tags: z.array(z.string()).optional(), source: z.record(z.string(), z.any()).optional() }),
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false, openWorldHint: false }
  }, async (input) => store.addObservation(input));

  register(server, 'kavya_map_work', { title: 'Map business work', description: 'Reconstruct work objects, states, actions, declared-vs-observed divergence, gaps and provenance.', inputSchema: z.object({ workObjectId: z.string().optional(), workObjectType: z.string().optional() }), annotations: { readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: false } }, async (input) => mapWork(await store.getState(), input));

  register(server, 'kavya_infer_intent', { title: 'Infer work intent', description: 'Produce an evidence-backed intent hypothesis. Never present intent as directly observed fact.', inputSchema: z.object({ workObjectId: z.string().optional(), evidence: z.array(z.any()).optional() }), annotations: { readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: false } }, async (input) => inferIntent(await store.getState(), input));

  register(server, 'kavya_identify_leverage', { title: 'Identify AI leverage', description: 'Scan candidate intervention points against a business-defined objective. Diagnostic, not prescriptive.', inputSchema: z.object({ objective: z.object({ metric: z.string(), direction: z.enum(['increase', 'decrease', 'maintain']), baseline: z.any().optional(), target: z.any().optional(), scope: z.string().optional(), constraints: z.array(z.string()).optional() }).optional() }), annotations: { readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: false } }, async ({ objective }) => identifyLeverage(await store.getState(), objective));

  register(server, 'kavya_plan_intervention', {
    title: 'Plan AI intervention', description: 'Record a case-specific wedge/system intervention hypothesis. Plan only; no external action is executed.',
    inputSchema: z.object({ id: z.string().optional(), mode: z.enum(['wedge', 'system']).optional(), workObjectId: z.string().optional(), workClass: z.string().optional(), layer: z.enum(METHODOLOGY.layers), hypothesis: z.string(), proposedCapability: z.string(), expectedChange: z.string().optional(), objective: z.object({ metric: z.string(), direction: z.enum(['increase', 'decrease', 'maintain']), baseline: z.any().optional(), target: z.any().optional(), scope: z.string().optional(), constraints: z.array(z.string()).optional() }).optional(), successMetric: z.record(z.string(), z.any()).optional(), guardrails: z.array(z.string()).optional(), autonomy: z.string().optional(), latencyMode: z.string().optional(), rollback: z.string().optional(), requiredEvidence: z.array(z.string()).optional(), evidence: z.array(z.any()).optional() }),
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false, openWorldHint: false }
  }, async (input) => store.addIntervention({ ...input, ...planIntervention(await store.getState(), input) }));

  register(server, 'kavya_define_measurement', { title: 'Define measurement', description: 'Create a baseline/target measurement contract before claiming intervention impact.', inputSchema: z.object({ id: z.string().optional(), interventionId: z.string().optional(), name: z.string(), metric: z.string(), direction: z.enum(['increase', 'decrease', 'maintain']), baseline: z.any().optional(), target: z.any().optional(), unit: z.string().optional(), scope: z.string().optional(), cadence: z.string().optional(), confounders: z.array(z.string()).optional(), notes: z.string().optional() }), annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false, openWorldHint: false } }, async (input) => store.defineMeasurement(input));

  register(server, 'kavya_record_outcome', { title: 'Record intervention outcome', description: 'Record an observed outcome with explicit attribution status and numeric delta where possible.', inputSchema: z.object({ id: z.string().optional(), measurementId: z.string(), observedAt: z.string().optional(), actual: z.any(), direction: z.enum(['increase', 'decrease', 'maintain']).optional(), context: z.record(z.string(), z.any()).optional(), evidence: z.array(z.any()).optional(), attribution: z.enum(['unknown', 'descriptive', 'supported', 'validated']).optional(), notes: z.string().optional() }), annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false, openWorldHint: false } }, async (input) => store.recordOutcome(input));

  register(server, 'kavya_record_exception', { title: 'Record workflow exception', description: 'Capture an exception and resolution for the learning loop. Do not silently generalize it.', inputSchema: z.object({ id: z.string().optional(), workObjectId: z.string().optional(), point: z.string(), type: z.string().optional(), description: z.string(), resolution: z.string().optional(), evidence: z.array(z.any()).optional(), reusable: z.enum(['yes', 'no', 'unknown']).optional(), validation: z.object({ status: z.string(), notes: z.string().optional() }).optional(), proposedLearning: z.string().optional() }), annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false, openWorldHint: false } }, async (input) => store.addException(input));

  register(server, 'kavya_promote_learning', { title: 'Promote exception learning', description: 'Record candidate organizational learning as knowledge, skill, policy, workflow, tool or UI capability. Validation is explicit.', inputSchema: z.object({ id: z.string().optional(), exceptionId: z.string(), type: z.enum(['knowledge', 'skill', 'policy', 'workflow', 'tool', 'ui']), title: z.string(), content: z.string(), validationStatus: z.enum(['candidate', 'validated', 'rejected']).optional(), evidence: z.array(z.any()).optional(), scope: z.string().optional(), nextReviewAt: z.string().optional() }), annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false, openWorldHint: false } }, async (input) => store.promoteLearning(input));

  register(server, 'kavya_get_operating_surface', { title: 'Get operating surface', description: 'Assemble the smallest useful current context for a work object so the person can interact with work instead of navigating source systems.', inputSchema: z.object({ workObjectId: z.string(), includeEvidence: z.boolean().default(true) }), annotations: { readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: false } }, async (input) => getOperatingSurface(await store.getState(), input));

  register(server, 'kavya_get_maturity', { title: 'Get Kavya maturity', description: 'Inspect multidimensional maturity across Kavya capability layers.', inputSchema: z.object({}), annotations: { readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: false } }, async () => maturitySnapshot(await store.getState()));

  register(server, 'kavya_assess', { title: 'Assess work system', description: 'Run a read-only composite Kavya diagnostic over work, intent, leverage and maturity.', inputSchema: z.object({ workObjectId: z.string().optional(), workObjectType: z.string().optional(), objective: z.object({ metric: z.string(), direction: z.enum(['increase', 'decrease', 'maintain']), baseline: z.any().optional(), target: z.any().optional(), scope: z.string().optional(), constraints: z.array(z.string()).optional() }).optional() }), annotations: { readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: false } }, async (input) => assess(await store.getState(), input));

  return server;
}

function authorized(req) {
  const expected = process.env.KAVYA_API_TOKEN;
  return !expected || req.headers.authorization === `Bearer ${expected}`;
}

function send(res, status, value) { res.writeHead(status, { 'content-type': 'application/json; charset=utf-8' }); res.end(JSON.stringify(value)); }
function readJson(req) { return new Promise((resolve, reject) => { let body = ''; req.setEncoding('utf8'); req.on('data', (c) => { body += c; if (body.length > 4 * 1024 * 1024) reject(new Error('Request too large')); }); req.on('end', () => { try { resolve(body ? JSON.parse(body) : undefined); } catch (e) { reject(e); } }); req.on('error', reject); }); }

const httpServer = createServer(async (req, res) => {
  try {
    if (req.url === '/healthz') return send(res, 200, { ok: true, service: 'kavya', version: '0.2.0' });
    if (!req.url?.startsWith('/mcp')) return send(res, 404, { error: 'Not found' });
    if (!authorized(req)) return send(res, 401, { error: 'Unauthorized' });
    const sessionId = req.headers['mcp-session-id'];
    let transport = sessionId ? sessions.get(sessionId) : undefined;
    if (req.method === 'POST') {
      if (!transport) {
        transport = new StreamableHTTPServerTransport({ sessionIdGenerator: () => randomUUID(), onsessioninitialized: (sid) => sessions.set(sid, transport) });
        transport.onclose = () => { if (transport.sessionId) sessions.delete(transport.sessionId); };
        await serverFactory().connect(transport);
      }
      return transport.handleRequest(req, res, await readJson(req));
    }
    if (req.method === 'GET' || req.method === 'DELETE') {
      if (!transport) return send(res, 400, { error: 'MCP session required' });
      return transport.handleRequest(req, res);
    }
    res.writeHead(405, { 'content-type': 'application/json', allow: 'GET, POST, DELETE' }); res.end(JSON.stringify({ error: 'Method not allowed' }));
  } catch (err) {
    console.error('[kavya]', err);
    if (!res.headersSent) send(res, 500, { error: 'Internal server error' });
  }
});

httpServer.listen(port, '0.0.0.0', () => console.error(`[kavya] listening on http://0.0.0.0:${port}/mcp`));
