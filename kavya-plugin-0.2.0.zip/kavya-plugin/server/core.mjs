import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';

const VERSION = 2;
const clone = (v) => JSON.parse(JSON.stringify(v));
const now = () => new Date().toISOString();
const makeId = (p) => `${p}_${crypto.randomUUID()}`;
const uniq = (xs) => [...new Set((xs ?? []).filter(Boolean))];

const DEFAULT_STATE = {
  version: VERSION,
  business: null,
  observations: [],
  exceptions: [],
  interventions: [],
  measurements: [],
  outcomes: [],
  learnings: [],
  updatedAt: null
};

function evidence(xs = []) {
  return xs.map((x) => typeof x === 'string' ? { ref: x } : clone(x));
}

function objective(x) {
  if (!x?.metric || !x?.direction) return null;
  return { metric: x.metric, direction: x.direction, baseline: x.baseline ?? null, target: x.target ?? null, scope: x.scope ?? null, constraints: clone(x.constraints ?? []) };
}

function migrate(raw) {
  const s = { ...clone(DEFAULT_STATE), ...raw, version: VERSION };
  for (const key of ['observations', 'exceptions', 'interventions', 'measurements', 'outcomes', 'learnings']) s[key] ??= [];
  s.observations = s.observations.map((o) => ({ ...o, signals: o.signals ?? [], evidence: evidence(o.evidence ?? []), source: o.source ?? null }));
  s.exceptions = s.exceptions.map((e) => ({ ...e, evidence: evidence(e.evidence ?? []), validation: e.validation ?? { status: 'unvalidated' } }));
  return s;
}

export class KavyaStore {
  constructor(filePath) { this.filePath = filePath; this.state = clone(DEFAULT_STATE); this.loaded = false; }

  async load() {
    if (this.loaded) return;
    try { this.state = migrate(JSON.parse(await fs.readFile(this.filePath, 'utf8'))); }
    catch (err) {
      if (err.code !== 'ENOENT') throw err;
      await fs.mkdir(path.dirname(this.filePath), { recursive: true });
      await this.save();
    }
    this.loaded = true;
  }

  async save() {
    this.state.updatedAt = now();
    await fs.mkdir(path.dirname(this.filePath), { recursive: true });
    const tmp = `${this.filePath}.${process.pid}.tmp`;
    await fs.writeFile(tmp, JSON.stringify(this.state, null, 2));
    await fs.rename(tmp, this.filePath);
  }

  async configureBusiness(input) {
    await this.load();
    this.state.business = { ...(this.state.business ?? {}), ...clone(input), updatedAt: now() };
    if (input.objective) this.state.business.objective = objective(input.objective);
    await this.save();
    return clone(this.state.business);
  }

  async addObservation(input) {
    await this.load();
    const observedWork = clone(input.observedWork ?? []);
    const signals = clone(input.signals ?? []);
    if (!observedWork.length && !signals.length) throw new Error('Observation requires observedWork or signals.');
    const item = {
      id: input.id ?? makeId('obs'), recordedAt: now(), observedAt: input.observedAt ?? now(),
      workObject: clone(input.workObject), declaredWork: input.declaredWork ?? null,
      observedWork, signals, context: clone(input.context ?? {}), outcome: clone(input.outcome ?? null),
      evidence: evidence(input.evidence ?? []), tags: clone(input.tags ?? []), source: clone(input.source ?? null)
    };
    this.state.observations.push(item); await this.save(); return clone(item);
  }

  async addException(input) {
    await this.load();
    const item = {
      id: input.id ?? makeId('exc'), recordedAt: now(), workObjectId: input.workObjectId ?? null,
      point: input.point, type: input.type ?? 'unknown', description: input.description,
      resolution: input.resolution ?? null, evidence: evidence(input.evidence ?? []), reusable: input.reusable ?? 'unknown',
      validation: clone(input.validation ?? { status: 'unvalidated' }), proposedLearning: input.proposedLearning ?? null
    };
    this.state.exceptions.push(item); await this.save(); return clone(item);
  }

  async addIntervention(input) {
    await this.load();
    const item = { id: input.id ?? makeId('int'), createdAt: now(), ...clone(input), status: 'planned', execution: 'plan_only' };
    this.state.interventions.push(item); await this.save(); return clone(item);
  }

  async defineMeasurement(input) {
    await this.load();
    const item = { id: input.id ?? makeId('mtr'), createdAt: now(), ...clone(input) };
    this.state.measurements.push(item); await this.save(); return clone(item);
  }

  async recordOutcome(input) {
    await this.load();
    const m = this.state.measurements.find((x) => x.id === input.measurementId);
    if (!m) throw new Error(`Measurement not found: ${input.measurementId}`);
    const delta = typeof m.baseline === 'number' && typeof input.actual === 'number'
      ? input.direction === 'increase' || m.direction === 'increase' ? input.actual - m.baseline : m.direction === 'decrease' ? m.baseline - input.actual : input.actual - m.baseline
      : null;
    const item = { id: input.id ?? makeId('out'), recordedAt: now(), ...clone(input), delta };
    this.state.outcomes.push(item); await this.save(); return clone(item);
  }

  async promoteLearning(input) {
    await this.load();
    const ex = this.state.exceptions.find((x) => x.id === input.exceptionId);
    if (!ex) throw new Error(`Exception not found: ${input.exceptionId}`);
    if (input.validationStatus === 'validated' && ex.validation?.status !== 'validated') throw new Error('Validation gate: source exception must be validated before learning is marked validated.');
    const item = { id: input.id ?? makeId('learn'), createdAt: now(), ...clone(input) };
    this.state.learnings.push(item); await this.save(); return clone(item);
  }

  async getState() { await this.load(); return clone(this.state); }
}

function observationsFor(state, workObjectId, workObjectType) {
  return state.observations.filter((o) => (!workObjectId || o.workObject?.id === workObjectId) && (!workObjectType || o.workObject?.type === workObjectType));
}

function divergence(obs) {
  const declared = uniq(obs.flatMap((o) => o.declaredWork ? [o.declaredWork] : []));
  const observed = uniq(obs.flatMap((o) => o.observedWork ?? []));
  const norm = (x) => x.toLowerCase();
  return {
    declared,
    observed,
    observedNotDeclared: observed.filter((x) => !declared.some((d) => norm(d).includes(norm(x)) || norm(x).includes(norm(d)))),
    declaredNotObserved: declared.filter((x) => !observed.some((o) => norm(o).includes(norm(x)) || norm(x).includes(norm(o))))
  };
}

export function mapWork(state, { workObjectId, workObjectType } = {}) {
  const obs = observationsFor(state, workObjectId, workObjectType);
  const groups = new Map();
  for (const o of obs) {
    const key = o.workObject?.id ?? `unbound:${o.id}`;
    const g = groups.get(key) ?? { id: key, type: o.workObject?.type ?? 'unknown', name: o.workObject?.name ?? null, states: [], actions: [], signals: [], declaredWork: [], outcomes: [], evidence: [], observations: [], gaps: [] };
    if (o.workObject?.state) g.states.push(o.workObject.state);
    g.actions.push(...(o.observedWork ?? [])); g.signals.push(...(o.signals ?? [])); if (o.declaredWork) g.declaredWork.push(o.declaredWork); if (o.outcome) g.outcomes.push(o.outcome); g.evidence.push(...o.evidence); g.observations.push(o.id); groups.set(key, g);
  }
  for (const g of groups.values()) {
    g.states = uniq(g.states); g.actions = uniq(g.actions); g.declaredWork = uniq(g.declaredWork); g.observations = uniq(g.observations);
    g.evidence = [...new Map(g.evidence.map((x) => [JSON.stringify(x), x])).values()];
    const d = divergence(obs.filter((o) => o.workObject?.id === g.id));
    g.observedNotDeclared = d.observedNotDeclared; g.declaredNotObserved = d.declaredNotObserved;
    if (d.observedNotDeclared.length || d.declaredNotObserved.length) g.gaps.push('declared_vs_observed_divergence');
    if (!g.states.length) g.gaps.push('state_missing');
    if (!g.evidence.length) g.gaps.push('provenance_missing');
  }
  return { generatedAt: now(), observationCount: obs.length, workObjects: [...groups.values()], completeness: obs.length ? 'partial_by_available_evidence' : 'no_evidence' };
}

export function inferIntent(state, { workObjectId, evidence: extra = [] } = {}) {
  const obs = observationsFor(state, workObjectId);
  if (!obs.length && !extra.length) return { intent: null, confidence: 'insufficient', evidence: [], disclaimer: 'No evidence is available.' };
  const d = divergence(obs);
  const context = obs.flatMap((o) => Object.entries(o.context ?? {}).map(([key, value]) => ({ key, value })));
  const outcomes = obs.flatMap((o) => o.outcome ? [o.outcome] : []);
  const score = Math.min(1, (d.declared.length ? 0.45 : 0) + (d.observed.length ? 0.3 : 0) + (context.length ? 0.1 : 0) + (outcomes.length ? 0.1 : 0) + (extra.length ? 0.05 : 0));
  const confidence = score >= 0.8 ? 'high' : score >= 0.55 ? 'medium' : 'low';
  return { intent: d.declared[0] ?? (d.observed.length ? `Advance work represented by: ${d.observed.slice(0, 6).join(', ')}` : null), confidence, confidenceScore: Number(score.toFixed(2)), evidence: { declaredWork: d.declared, observedWork: d.observed, observedNotDeclared: d.observedNotDeclared, declaredNotObserved: d.declaredNotObserved, context, outcomes, additionalEvidence: evidence(extra) }, disclaimer: 'Intent is an evidence-backed hypothesis, not a directly observed fact.' };
}

function inferLayers(o) {
  const t = [JSON.stringify(o.declaredWork ?? ''), ...(o.observedWork ?? []), ...(o.signals ?? []).map(JSON.stringify), JSON.stringify(o.context ?? {})].join(' ').toLowerCase();
  const layers = [];
  if (/crm|erp|email|slack|drive|system|connector|reconcil/.test(t)) layers.push('integration');
  if (/policy|sop|document|knowledge|precedent|history/.test(t)) layers.push('knowledge');
  if (/approval|handoff|route|workflow|ticket|state/.test(t)) layers.push('workflow');
  if (/decision|forecast|scenario|recommend|signal/.test(t)) layers.push('decision');
  if (/tool|calculator|dashboard|interface|app/.test(t)) layers.push('creation');
  if (/sql|query|data|report|csv|analytics/.test(t)) layers.push('data');
  if (/ui|surface|screen|click|tab/.test(t)) layers.push('experience');
  return uniq(layers);
}

export function identifyLeverage(state, obj = null) {
  const o = objective(obj ?? state.business?.objective ?? state.business?.objectives?.[0]);
  if (!o) return { mode: 'diagnostic', candidates: [], note: 'No business-defined objective is configured. Kavya does not invent one.' };
  const candidates = state.observations.map((x) => ({ observationId: x.id, workObjectId: x.workObject?.id ?? null, workObjectType: x.workObject?.type ?? 'unknown', state: x.workObject?.state ?? null, actionCount: (x.observedWork ?? []).length, evidenceCount: (x.evidence ?? []).length, possibleLayers: inferLayers(x), evidenceStrength: Number(((x.observedWork ?? []).length + (x.evidence ?? []).length * 0.5 + (x.declaredWork ? 1 : 0)).toFixed(2)) }));
  candidates.sort((a, b) => b.evidenceStrength - a.evidenceStrength);
  return { mode: 'leverage_scan', objective: o, candidates: candidates.slice(0, 25), selectionRule: 'Diagnostic evidence strength only; business-specific impact, feasibility and risk remain case-specific.' };
}

export function planIntervention(state, input) {
  const business = state.business ?? {};
  return {
    mode: input.mode ?? 'wedge', workObjectId: input.workObjectId ?? null, workClass: input.workClass ?? null,
    layer: input.layer, hypothesis: input.hypothesis, proposedCapability: input.proposedCapability,
    objective: objective(input.objective ?? business.objective ?? business.objectives?.[0]),
    expectedChange: input.expectedChange ?? null, successMetric: clone(input.successMetric ?? null),
    guardrails: clone(input.guardrails ?? []), autonomy: input.autonomy ?? business.autonomy?.default ?? null,
    latencyMode: input.latencyMode ?? business.latency?.mode ?? null, rollback: input.rollback ?? null,
    requiredEvidence: clone(input.requiredEvidence ?? []), execution: 'plan_only'
  };
}

export function getOperatingSurface(state, { workObjectId, includeEvidence = true } = {}) {
  const obs = observationsFor(state, workObjectId);
  if (!obs.length) return { found: false, workObjectId };
  const latest = obs.at(-1);
  const exceptions = state.exceptions.filter((e) => e.workObjectId === workObjectId);
  return {
    found: true, workObject: clone(latest.workObject), currentState: latest.workObject?.state ?? null,
    context: clone(latest.context), recentActions: obs.flatMap((o) => o.observedWork ?? []).slice(-12),
    declaredWork: latest.declaredWork, decisions: latest.context?.decisions ?? [], nextAction: latest.context?.nextAction ?? null,
    pendingExceptions: exceptions.filter((e) => !e.resolution), relatedInterventions: state.interventions.filter((i) => i.workObjectId === workObjectId),
    relatedLearnings: state.learnings.filter((l) => exceptions.some((e) => e.id === l.exceptionId)), provenance: { observationIds: obs.map((o) => o.id) },
    ...(includeEvidence ? { evidence: obs.flatMap((o) => o.evidence ?? []).slice(-20) } : {})
  };
}

export function maturitySnapshot(state) {
  const layers = ['integration', 'knowledge', 'workflow', 'decision', 'creation', 'data', 'experience'];
  const scores = state.business?.maturity?.layer_scores ?? {};
  return {
    model: 'maturity_vector',
    vector: Object.fromEntries(layers.map((x) => [x, typeof scores[x] === 'number' ? scores[x] : 0])),
    signals: { observations: state.observations.length, interventions: state.interventions.length, measurements: state.measurements.length, outcomes: state.outcomes.length, exceptions: state.exceptions.length, learnings: state.learnings.length },
    targets: clone(state.business?.maturity?.target_layers ?? {}),
    note: 'Maturity is multidimensional and workflow-specific; it is not a universal ranking.'
  };
}

export function assess(state, input = {}) {
  const obj = objective(input.objective ?? state.business?.objective ?? state.business?.objectives?.[0]);
  return { generatedAt: now(), objective: obj, workMap: mapWork(state, input), intent: input.workObjectId ? inferIntent(state, { workObjectId: input.workObjectId }) : null, leverage: identifyLeverage(state, obj), maturity: maturitySnapshot(state), evidenceBoundary: 'Assessment reflects only data available to the facilitator.' };
}

export const METHODOLOGY = Object.freeze({
  identity: 'Kavya — The Operating Surface',
  role: 'Infrastructure provider, not opinion maker.',
  thesis: 'Employees stop navigating tools. They interact with work itself.',
  principle: 'Philosophy comes first; code facilitates it.',
  loop: ['observe', 'map', 'identify_leverage', 'intervene', 'measure', 'handle_exceptions', 'learn', 'expand'],
  layers: ['integration', 'knowledge', 'workflow', 'decision', 'creation', 'data', 'experience'],
  evidenceChain: ['evidence', 'reconstruction', 'inference', 'recommendation', 'decision', 'action'],
  autonomy: ['retrieve', 'interpret', 'generate', 'recommend', 'approve', 'act_within_constraints', 'act_autonomously']
});
