import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { KavyaStore, mapWork, inferIntent, identifyLeverage, planIntervention, getOperatingSurface, maturitySnapshot, assess } from '../server/core.mjs';

async function tempStore() {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'kavya-'));
  return new KavyaStore(path.join(dir, 'state.json'));
}

test('business objective is explicit', async () => {
  const s = await tempStore();
  const b = await s.configureBusiness({ name: 'Example', objective: { metric: 'cycle_time', direction: 'decrease', baseline: 9.3 } });
  assert.equal(b.objective.metric, 'cycle_time');
});

test('observation preserves expected/observed distinction and provenance', async () => {
  const s = await tempStore();
  await s.addObservation({ workObject: { id: 'D1', type: 'deal', state: 'pending' }, declaredWork: 'Review pricing exception', observedWork: ['open CRM', 'search policy', 'request approval'], evidence: ['crm:D1'] });
  const m = mapWork(await s.getState(), { workObjectId: 'D1' });
  assert.equal(m.workObjects[0].actions.length, 3);
  assert.equal(m.workObjects[0].evidence[0].ref, 'crm:D1');
  assert.ok(m.workObjects[0].observedNotDeclared.includes('open CRM'));
});

test('intent is represented as an evidence-backed hypothesis', async () => {
  const s = await tempStore();
  await s.addObservation({ workObject: { id: 'D1', type: 'deal' }, declaredWork: 'Review pricing exception', observedWork: ['search policy', 'request approval'], context: { stage: 'late' } });
  const r = inferIntent(await s.getState(), { workObjectId: 'D1' });
  assert.equal(r.intent, 'Review pricing exception');
  assert.match(r.disclaimer, /hypothesis/);
  assert.ok(r.confidenceScore > 0.5);
});

test('leverage requires a business objective and remains diagnostic', async () => {
  const s = await tempStore();
  await s.addObservation({ workObject: { id: 'D1', type: 'deal' }, observedWork: ['open CRM'] });
  assert.equal(identifyLeverage(await s.getState()).mode, 'diagnostic');
  const r = identifyLeverage(await s.getState(), { metric: 'cycle_time', direction: 'decrease' });
  assert.equal(r.mode, 'leverage_scan');
  assert.equal(r.objective.metric, 'cycle_time');
  assert.match(r.selectionRule, /business-specific/);
});

test('intervention planning is separated from execution', async () => {
  const s = await tempStore();
  await s.configureBusiness({ objective: { metric: 'cycle_time', direction: 'decrease' }, autonomy: { default: 'recommend' } });
  const r = planIntervention(await s.getState(), { layer: 'workflow', hypothesis: 'Context fragmented', proposedCapability: 'Context assembly' });
  assert.equal(r.execution, 'plan_only');
  assert.equal(r.autonomy, 'recommend');
});

test('outcomes compute a transparent numeric delta', async () => {
  const s = await tempStore();
  const m = await s.defineMeasurement({ name: 'Approval time', metric: 'cycle_time', direction: 'decrease', baseline: 9.3, target: 1, unit: 'days' });
  const o = await s.recordOutcome({ measurementId: m.id, actual: 4.1, attribution: 'descriptive' });
  assert.equal(Number(o.delta.toFixed(1)), 5.2);
});

test('validated learning is gated by validated exception', async () => {
  const s = await tempStore();
  const ex = await s.addException({ workObjectId: 'D1', point: 'approval', description: 'Policy conflict' });
  await assert.rejects(() => s.promoteLearning({ exceptionId: ex.id, type: 'skill', title: 'Resolve conflict', content: '...', validationStatus: 'validated' }), /Validation gate/);
  await s.addException({ id: 'EX2', workObjectId: 'D1', point: 'approval', description: 'resolved', resolution: 'Use policy B', validation: { status: 'validated' } });
  const l = await s.promoteLearning({ exceptionId: 'EX2', type: 'skill', title: 'Resolve conflict', content: 'Use policy B', validationStatus: 'validated' });
  assert.equal(l.validationStatus, 'validated');
});

test('operating surface is context-first', async () => {
  const s = await tempStore();
  await s.addObservation({ workObject: { id: 'D1', type: 'deal', state: 'pending_approval' }, observedWork: ['request approval'], context: { nextAction: 'manager approval' }, evidence: ['crm:D1'] });
  const r = getOperatingSurface(await s.getState(), { workObjectId: 'D1' });
  assert.equal(r.currentState, 'pending_approval');
  assert.equal(r.nextAction, 'manager approval');
});

test('maturity is multidimensional', async () => {
  const s = await tempStore();
  await s.configureBusiness({ maturity: { layer_scores: { integration: 3, knowledge: 1 } } });
  const r = maturitySnapshot(await s.getState());
  assert.equal(r.model, 'maturity_vector');
  assert.equal(r.vector.integration, 3);
  assert.equal(r.vector.knowledge, 1);
});

test('composite assessment stays bounded by available evidence', async () => {
  const s = await tempStore();
  await s.configureBusiness({ objective: { metric: 'cycle_time', direction: 'decrease' } });
  await s.addObservation({ workObject: { id: 'D1', type: 'deal', state: 'pending' }, declaredWork: 'Review exception', observedWork: ['search policy'] });
  const r = assess(await s.getState(), { workObjectId: 'D1' });
  assert.equal(r.objective.metric, 'cycle_time');
  assert.equal(r.workMap.workObjects.length, 1);
  assert.equal(r.intent.intent, 'Review exception');
  assert.match(r.evidenceBoundary, /available to the facilitator/);
});
