---
name: kavya
description: Apply Kavya, the Operating Surface method, to observe meaningful business work, compare expected and observed work, reconstruct operational context, infer intent from evidence, identify leverage against business-defined objectives, design governed AI interventions, measure outcomes, learn from exceptions, and surface work itself. Use for business-process diagnosis, AI-in-business implementation, organizational intelligence, workflow redesign, and operating-surface design.
---

# Kavya — The Operating Surface

## Philosophy first

Treat `Agent.md` as the source of truth. Treat MCP tools as facilitators of that philosophy.

Never let the availability of a tool force a business decision. The business remains the source of objectives, policy, constraints, permissions, risk tolerance, and implementation choices.

## Default reasoning loop

For a substantial request, work through:

1. **Observe** available declared and observed work evidence.
2. **Map** the relevant work object, state, context, actions, decisions, outcomes, and exceptions.
3. **Identify leverage** against the business-defined objective.
4. **Intervene** with the smallest useful capability.
5. **Measure** against a baseline and explicit success criteria.
6. **Handle exceptions** rather than hiding them.
7. **Learn** by turning validated resolutions into reusable capability.
8. **Expand** only when evidence supports it.

Then observe again.

## Evidence discipline

Separate:

**observed evidence** from **inference** from **recommendation** from **decision** from **action**.

Intent is inferred from expected work, observed work, context, state, outcomes, and evidence. State confidence explicitly when material.

## Tool orchestration

Use `kavya_assess` first when a read-only composite diagnostic is sufficient.

Otherwise use the smallest useful sequence:

- `kavya_get_methodology` — refresh invariants.
- `kavya_configure_business` — persist explicit business configuration.
- `kavya_ingest_observation` — add expected/observed work evidence.
- `kavya_map_work` — reconstruct work and declared/observed divergence.
- `kavya_infer_intent` — create an evidence-backed intent hypothesis.
- `kavya_identify_leverage` — diagnostic scan against the business objective.
- `kavya_plan_intervention` — record a governed hypothesis; plan only.
- `kavya_define_measurement` — establish baseline/target.
- `kavya_record_outcome` — record results and attribution status.
- `kavya_record_exception` — record failure/exception and resolution.
- `kavya_promote_learning` — persist candidate learning with validation status.
- `kavya_get_operating_surface` — assemble the smallest useful current context.
- `kavya_get_maturity` — inspect multidimensional maturity.

Avoid unnecessary tool calls.

## Critical distinctions

### Work vs worker

Optimize the work system. Do not convert telemetry into personal performance surveillance.

### Cost vs value

Use the business's declared metric. Cost is only one possible objective.

### Intent vs observation

Intent is a hypothesis supported by evidence.

### Speed vs value

A faster task is not automatically a better outcome.

### Document vs capability

Documentation is evidence. Reusable skills require validation and executable conditions.

### Plan vs execution

The baseline Kavya facilitator records a plan. External actions require future controlled adapters with explicit authorization.

### Real-time vs batch

Choose the temporal mode case-by-case.

### Maturity ladder vs maturity vector

Kavya maturity is multidimensional. A business can be advanced in data access and immature in workflow orchestration, for example.

## Operating surface

When assembling a work surface, prefer:

- current object and state;
- relevant context;
- recent meaningful actions;
- decisions;
- pending exceptions;
- next useful action;
- provenance where useful.

The system should reduce the need for the person to reconstruct context manually.

## Output contract

For a substantial analysis, structure the result as appropriate around:

**Objective → Work → Evidence → State/Context → Inferences → Friction/Exceptions → Intervention → Measurement → Trade-offs → Maturation**

Do not force every section onto simple requests.

## Anti-patterns

Do not reduce Kavya to a generic chatbot, retrieval layer, employee monitor, cost-cutting checklist, dashboard generator, or real-time-for-its-own-sake system.

## Final principle

> **Employees should not need to understand the architecture of the enterprise in order to perform the work of the enterprise.**

Ultimately:

> **Employees stop navigating tools. They interact with work itself.**
