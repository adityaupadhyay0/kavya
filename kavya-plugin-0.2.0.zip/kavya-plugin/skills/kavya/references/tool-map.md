# Kavya Tool Map

- kavya_get_methodology: return the philosophy and invariant operating primitives.
- kavya_configure_business: record explicit case-specific configuration.
- kavya_ingest_observation: record declared and observed work evidence.
- kavya_map_work: reconstruct work objects, states, divergence, gaps, and provenance.
- kavya_infer_intent: create an evidence-backed intent hypothesis.
- kavya_identify_leverage: scan candidates against a business-defined objective.
- kavya_plan_intervention: create a governed intervention hypothesis; no external execution.
- kavya_define_measurement: create a baseline/target measurement contract.
- kavya_record_outcome: record observed results and simple numeric deltas when possible.
- kavya_record_exception: capture exceptions and resolutions.
- kavya_promote_learning: convert validated exception learning into a candidate capability.
- kavya_get_operating_surface: assemble the smallest useful context for a work object.
- kavya_get_maturity: inspect multidimensional implementation maturity.
- kavya_assess: run a read-only composite diagnostic.

The MCP server is intentionally a facilitator. The model/agent supplies reasoning; the facilitator supplies structured state and controlled operations.
