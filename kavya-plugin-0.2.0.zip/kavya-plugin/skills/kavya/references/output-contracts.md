# Kavya Output Contracts

For substantial analyses, keep these sections distinct:

1. Business objective
2. Work object / work class
3. Observed evidence
4. Reconstructed context and state
5. Inferences (including intent)
6. Friction / dependencies / exceptions
7. Candidate interventions
8. Measurement and baseline
9. Trade-offs / constraints
10. Maturation path

Never collapse observed evidence and inference into one statement.
