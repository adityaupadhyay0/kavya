# Kavya Architecture Reference

Kavya has two complementary structures.

## Capability layers

1. Integration — connect systems and assemble operational context.
2. Knowledge — preserve organizational memory and attach it to work.
3. Workflow — move context through work and exceptions.
4. Decision — surface signals, scenarios, narratives, and decisions at the point of work.
5. Creation — generate business-specific tools and interfaces.
6. Data — provide source-attributed access to organizational data.
7. Experience — present adaptive work surfaces around the work itself.

These are capability locations, not a universal implementation checklist.

## Operating loop

Observe → Map → Identify leverage → Intervene → Measure → Handle exceptions → Learn → Expand → Observe again.

## Work representation

When useful, represent a work object as:

object + state + context + actors + actions + decisions + knowledge + outcomes + exceptions.

## Product boundary

Kavya is infrastructure. The business decides objectives, scope, policies, constraints, autonomy, and implementation details case-by-case.
