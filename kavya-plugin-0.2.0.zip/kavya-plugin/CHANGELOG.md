# Changelog

## 0.2.0 — Philosophy made executable

- Refactored Kavya around an explicit philosophy → agent → facilitator boundary.
- Added `Agent.md` as the canonical behavioral contract.
- Added a focused `SKILL.md` plus architecture, output-contract, and tool-map references.
- Added `kavya_get_methodology` so the facilitator can expose its invariants directly.
- Added explicit expected/declared vs observed work modeling.
- Added first-class evidence/provenance records.
- Added diagnostic intent inference with explicit hypothesis language.
- Added objective-aware leverage diagnostics without silently choosing the business objective.
- Added governed intervention planning with explicit plan-only execution semantics.
- Added measurement contracts and outcome attribution.
- Added exception learning with validation gating before promotion.
- Changed maturity from a global ladder to a multidimensional capability vector.
- Added `kavya_assess` as a compact read-only composite diagnostic.
- Added output schemas and MCP tool annotations.
- Added MCP session DELETE handling and a health endpoint.
- Added optional bearer-token development gating while documenting production auth requirements.
- Added compatibility manifest and local marketplace metadata.

## 0.1.0

Initial Kavya facilitator prototype.
